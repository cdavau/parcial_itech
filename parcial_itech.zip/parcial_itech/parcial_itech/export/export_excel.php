<?php
require_once __DIR__ . '/../app/bootstrap.php';

$registros = Inscriptor::reporte();

$archivo = 'reporte_inscriptores_' . date('Y-m-d_His') . '.xls';
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $archivo . '"');
header('Pragma: no-cache');
header('Expires: 0');

echo "\xEF\xBB\xBF"; // BOM UTF-8 para acentos
?>
<table border="1">
    <thead>
        <tr style="background:#0b5cad;color:#fff;font-weight:bold;">
            <th>Integridad</th><th>Identidad</th><th>Nombre</th><th>Apellido</th>
            <th>Edad</th><th>Sexo</th><th>Residencia</th><th>Nacionalidad</th>
            <th>Correo</th><th>Celular</th><th>Temas</th><th>Observaciones</th><th>Fecha</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($registros as $r):
        $integro = Firma::verificar($r, $r['firma'] ?? null) ? 'Íntegro' : 'Corrompido';
    ?>
        <tr>
            <td><?= $integro ?></td>
            <td><?= htmlspecialchars($r['identidad']) ?></td>
            <td><?= htmlspecialchars($r['nombre']) ?></td>
            <td><?= htmlspecialchars($r['apellido']) ?></td>
            <td><?= (int)$r['edad'] ?></td>
            <td><?= htmlspecialchars($r['sexo']) ?></td>
            <td><?= htmlspecialchars($r['pais_residencia']) ?></td>
            <td><?= htmlspecialchars($r['nacionalidad']) ?></td>
            <td><?= htmlspecialchars($r['correo']) ?></td>
            <td><?= htmlspecialchars($r['celular']) ?></td>
            <td><?= htmlspecialchars($r['temas'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['observaciones'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['fecha_registro']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
