<?php
class AreaInteres
{
    public static function todas(): array
    {
        return Database::getInstance()->fetchAll('SELECT id, nombre FROM areas_interes ORDER BY nombre');
    }
}
