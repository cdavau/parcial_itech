<?php
class Inscriptor
{
    public static function crear(array $limpio): int
    {
        $db  = Database::getInstance();
        $pdo = $db->pdo();
        $firma = Firma::firmar($limpio);

        try {
            $pdo->beginTransaction();

            $sql = 'INSERT INTO inscriptores
                    (identidad, nombre, apellido, edad, sexo,
                     pais_residencia_id, nacionalidad_id, correo, celular,
                     observaciones, firma)
                    VALUES (:identidad, :nombre, :apellido, :edad, :sexo,
                            :pais, :nac, :correo, :celular, :obs, :firma)';
            $db->query($sql, [
                ':identidad' => $limpio['identidad'],
                ':nombre'    => $limpio['nombre'],
                ':apellido'  => $limpio['apellido'],
                ':edad'      => $limpio['edad'],
                ':sexo'      => $limpio['sexo'],
                ':pais'      => $limpio['pais_residencia_id'],
                ':nac'       => $limpio['nacionalidad_id'],
                ':correo'    => $limpio['correo'],
                ':celular'   => $limpio['celular'],
                ':obs'       => $limpio['observaciones'],
                ':firma'     => $firma,
            ]);
            $id = $db->lastInsertId();

            $sqlTema = 'INSERT INTO inscriptor_temas (inscriptor_id, area_interes_id)
                        VALUES (:insc, :area)';
            foreach ($limpio['temas'] as $areaId) {
                $db->query($sqlTema, [':insc' => $id, ':area' => $areaId]);
            }

            $pdo->commit();
            return $id;
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function reporte(): array
    {
        $sql = "SELECT  i.id, i.identidad, i.nombre, i.apellido, i.edad, i.sexo,
                        pr.nombre  AS pais_residencia,
                        na.nombre  AS nacionalidad,
                        i.correo, i.celular, i.observaciones, i.firma,
                        i.fecha_registro,
                        GROUP_CONCAT(a.nombre ORDER BY a.nombre SEPARATOR ', ') AS temas
                FROM inscriptores i
                JOIN paises pr        ON pr.id = i.pais_residencia_id
                JOIN paises na        ON na.id = i.nacionalidad_id
                LEFT JOIN inscriptor_temas it ON it.inscriptor_id = i.id
                LEFT JOIN areas_interes  a    ON a.id = it.area_interes_id
                GROUP BY i.id
                ORDER BY i.fecha_registro DESC";
        return Database::getInstance()->fetchAll($sql);
    }

    public static function existe(string $identidad, string $correo): bool
    {
        $fila = Database::getInstance()->fetch(
            'SELECT id FROM inscriptores WHERE identidad = :i OR correo = :c LIMIT 1',
            [':i' => $identidad, ':c' => $correo]
        );
        return $fila !== null;
    }
}
