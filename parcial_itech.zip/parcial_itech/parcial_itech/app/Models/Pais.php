<?php
class Pais
{
    public static function todos(): array
    {
        return Database::getInstance()->fetchAll('SELECT id, nombre FROM paises ORDER BY nombre');
    }
}
