<?php

class InscriptorController
{
    public function formulario(array $errores = [], array $viejo = [], string $exito = ''): void
    {
        $paises = Pais::todos();
        $areas  = AreaInteres::todas();
        require BASE_PATH . '/app/Views/formulario.php';
    }

    public function guardar(): void
    {
        $limpio = Sanitizer::limpiarInscriptor($_POST);

        $errores = Validator::validarInscriptor($limpio);

        // no duplicar identidad/correo
        if (empty($errores) && Inscriptor::existe($limpio['identidad'], $limpio['correo'])) {
            $errores['identidad'] = 'Ya existe un inscriptor con esa identidad o correo.';
        }

        if (!empty($errores)) {
            $this->formulario($errores, $_POST);
            return;
        }

        //  Guardar
        try {
            Inscriptor::crear($limpio);
            $this->formulario([], [], 'Inscripción registrada correctamente.');
        } catch (Throwable $e) {
            $this->formulario(['general' => 'Error al guardar: ' . $e->getMessage()], $_POST);
        }
    }

    /** Muestra el reporte con verificación de integridad */
    public function reporte(): void
    {
        $registros = Inscriptor::reporte();
        require BASE_PATH . '/app/Views/reporte.php';
    }
}
