<?php
$titulo = 'iTECH · Formulario de Inscripción';
$errores = $errores ?? [];
$viejo   = $viejo ?? [];
$exito   = $exito ?? '';

function old(string $campo, array $viejo, string $def = ''): string
{
    return htmlspecialchars($viejo[$campo] ?? $def);
}
function sel($a, $b): string { return (string)$a === (string)$b ? 'selected' : ''; }

require __DIR__ . '/partials/header.php';
?>

<h1 class="page-title">Formulario de Inscripción</h1>
<p class="subtitle">Regístrate para el evento tecnológico de iTECH.</p>

<?php if ($exito): ?>
    <div class="alert alert-ok"><?= htmlspecialchars($exito) ?></div>
<?php endif; ?>
<?php if (!empty($errores['general'])): ?>
    <div class="alert alert-error"><?= htmlspecialchars($errores['general']) ?></div>
<?php endif; ?>

<form class="card" action="index.php?accion=guardar" method="post" novalidate>

    <fieldset>
        <legend>Datos personales</legend>

        <div class="grid">
            <div class="field">
                <label>Cédula de identidad *</label>
                <input type="text" name="identidad" value="<?= old('identidad', $viejo) ?>"
                       placeholder="8-888-8888">
                <?php if (!empty($errores['identidad'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['identidad']) ?></small>
                <?php endif; ?>
            </div>

            <div class="field">
                <label>Nombre *</label>
                <input type="text" name="nombre" value="<?= old('nombre', $viejo) ?>">
                <?php if (!empty($errores['nombre'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['nombre']) ?></small>
                <?php endif; ?>
            </div>

            <div class="field">
                <label>Apellido *</label>
                <input type="text" name="apellido" value="<?= old('apellido', $viejo) ?>">
                <?php if (!empty($errores['apellido'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['apellido']) ?></small>
                <?php endif; ?>
            </div>

            <div class="field">
                <label>Edad *</label>
                <input type="number" name="edad" min="15" max="100" value="<?= old('edad', $viejo) ?>">
                <?php if (!empty($errores['edad'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['edad']) ?></small>
                <?php endif; ?>
            </div>

            <div class="field">
                <label>Sexo *</label>
                <select name="sexo">
                    <option value="">-- Seleccione --</option>
                    <?php foreach (['Masculino', 'Femenino', 'Otro'] as $s): ?>
                        <option value="<?= $s ?>" <?= sel($s, $viejo['sexo'] ?? '') ?>><?= $s ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if (!empty($errores['sexo'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['sexo']) ?></small>
                <?php endif; ?>
            </div>

            <div class="field">
                <label>País de Residencia *</label>
                <select name="pais_residencia_id">
                    <option value="">-- Seleccione --</option>
                    <?php foreach ($paises as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= sel($p['id'], $viejo['pais_residencia_id'] ?? '') ?>>
                            <?= htmlspecialchars($p['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (!empty($errores['pais_residencia_id'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['pais_residencia_id']) ?></small>
                <?php endif; ?>
            </div>

            <div class="field">
                <label>Nacionalidad *</label>
                <select name="nacionalidad_id">
                    <option value="">-- Seleccione --</option>
                    <?php foreach ($paises as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= sel($p['id'], $viejo['nacionalidad_id'] ?? '') ?>>
                            <?= htmlspecialchars($p['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (!empty($errores['nacionalidad_id'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['nacionalidad_id']) ?></small>
                <?php endif; ?>
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Información de contacto</legend>
        <div class="grid">
            <div class="field">
                <label>Correo *</label>
                <input type="email" name="correo" value="<?= old('correo', $viejo) ?>"
                       placeholder="nombre@correo.com">
                <?php if (!empty($errores['correo'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['correo']) ?></small>
                <?php endif; ?>
            </div>
            <div class="field">
                <label>Celular *</label>
                <input type="text" name="celular" value="<?= old('celular', $viejo) ?>"
                       placeholder="+507 6000-0000">
                <?php if (!empty($errores['celular'])): ?>
                    <small class="err"><?= htmlspecialchars($errores['celular']) ?></small>
                <?php endif; ?>
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Temas tecnológicos que te gustaría aprender *</legend>
        <div class="checkboxes">
            <?php
            $temasViejos = (array)($viejo['temas'] ?? []);
            foreach ($areas as $a):
                $checked = in_array((string)$a['id'], array_map('strval', $temasViejos), true) ? 'checked' : '';
            ?>
                <label class="check">
                    <input type="checkbox" name="temas[]" value="<?= $a['id'] ?>" <?= $checked ?>>
                    <span><?= htmlspecialchars($a['nombre']) ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <?php if (!empty($errores['temas'])): ?>
            <small class="err"><?= htmlspecialchars($errores['temas']) ?></small>
        <?php endif; ?>
    </fieldset>

    <fieldset>
        <legend>Observaciones</legend>
        <div class="field">
            <label>Observaciones o consulta sobre el evento</label>
            <textarea name="observaciones" rows="4"><?= old('observaciones', $viejo) ?></textarea>
        </div>
    </fieldset>

    <div class="actions">
        <button type="submit" class="btn btn-primary">Registrar inscripción</button>
        <a class="btn btn-ghost" href="index.php?accion=reporte">Ver reporte</a>
    </div>
</form>

<?php require __DIR__ . '/partials/footer.php'; ?>
