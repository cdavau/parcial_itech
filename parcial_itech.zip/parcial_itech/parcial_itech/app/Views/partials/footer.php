<?php  ?>
</main>
<footer class="footer">
    <p>&copy; <?= date('Y') ?> <?= htmlspecialchars(APP_NOMBRE) ?>. All rights reserved.</p>
    <p class="contacto"><?= htmlspecialchars(APP_CONTACTO) ?></p>
</footer>
</body>
</html>
