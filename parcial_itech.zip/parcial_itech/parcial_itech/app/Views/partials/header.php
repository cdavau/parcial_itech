<?php ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo ?? 'iTECH') ?></title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
<header class="topbar">
    <div class="brand">
        <span class="logo">iTECH</span>
        <span class="tag">Inscripciones a temas de interés</span>
    </div>
    <nav>
        <a href="index.php?accion=formulario">Formulario</a>
        <a href="index.php?accion=reporte">Reporte</a>
    </nav>
</header>
<main class="container">
