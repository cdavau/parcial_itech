<?php
$titulo = 'iTECH · Reporte de Inscripciones';
require __DIR__ . '/partials/header.php';
?>

<div class="report-head">
    <h1 class="page-title">Reporte de Inscripciones</h1>
    <a class="btn btn-primary" href="export/export_excel.php">⬇ Exportar a Excel</a>
</div>

<div class="legend">
    <span class="badge badge-ok">● Íntegro</span> datos verificados con OpenSSL &nbsp;|&nbsp;
    <span class="badge badge-bad">● Corrompido</span> firma inválida / datos alterados
</div>

<?php if (empty($registros)): ?>
    <p class="empty">Aún no hay inscripciones registradas.</p>
<?php else: ?>
<div class="table-wrap">
<table class="report">
    <thead>
        <tr>
            <th>Integridad</th>
            <th>Identidad</th>
            <th>Nombre</th>
            <th>Edad</th>
            <th>Sexo</th>
            <th>Residencia</th>
            <th>Nacionalidad</th>
            <th>Correo</th>
            <th>Celular</th>
            <th>Temas</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($registros as $r):   
        $integro = Firma::verificar($r, $r['firma'] ?? null);
    ?>
        <tr>
            <td>
                <?php if ($integro): ?>
                    <span class="badge badge-ok" title="Registro validado">● Íntegro</span>
                <?php else: ?>
                    <span class="badge badge-bad" title="Registro corrompido o alterado">● Corrompido</span>
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($r['identidad']) ?></td>
            <td><?= htmlspecialchars($r['nombre'] . ' ' . $r['apellido']) ?></td>
            <td><?= (int)$r['edad'] ?></td>
            <td><?= htmlspecialchars($r['sexo']) ?></td>
            <td><?= htmlspecialchars($r['pais_residencia']) ?></td>
            <td><?= htmlspecialchars($r['nacionalidad']) ?></td>
            <td><?= htmlspecialchars($r['correo']) ?></td>
            <td><?= htmlspecialchars($r['celular']) ?></td>
            <td><?= htmlspecialchars($r['temas'] ?? '—') ?></td>
            <td><?= htmlspecialchars($r['fecha_registro']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
<?php endif; ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
