Q<?php
class Firma
{
    private static string $priv = KEYS_PATH . '/private.pem';
    private static string $pub  = KEYS_PATH . '/public.pem';

    public static function asegurarLlaves(): void
    {
        if (is_file(self::$priv) && is_file(self::$pub)) {
            return;
        }
        if (!is_dir(KEYS_PATH)) {
            mkdir(KEYS_PATH, 0755, true);
        }

        $config = [
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ];

        $cnf = BASE_PATH . '/config/openssl.cnf';
        if (is_file($cnf)) {
            $config['config'] = $cnf;
        }

        $res = openssl_pkey_new($config);
        if ($res === false) {
            throw new RuntimeException(
                'No se pudo generar el par de llaves OpenSSL. Revisa que la '
                . 'extensión php_openssl esté activa y que exista '
                . 'config/openssl.cnf. Detalle: ' . openssl_error_string()
            );
        }

        openssl_pkey_export($res, $privadaPem, null, $config); 
        $detalles = openssl_pkey_get_details($res);
        file_put_contents(self::$priv, $privadaPem);
        file_put_contents(self::$pub, $detalles['key']);      
    }

    public static function cadenaCanonica(array $d): string
    {
        return implode('|', [
            trim($d['identidad'] ?? ''),
            trim($d['nombre'] ?? '') . ' ' . trim($d['apellido'] ?? ''),
            trim($d['correo'] ?? ''),
            trim($d['celular'] ?? ''),
            trim($d['sexo'] ?? ''),
        ]);
    }

    public static function firmar(array $datos): string
    {
        self::asegurarLlaves();
        $privada = openssl_pkey_get_private(file_get_contents(self::$priv));
        openssl_sign(self::cadenaCanonica($datos), $firma, $privada, OPENSSL_ALGO_SHA256);
        return base64_encode($firma);
    }

    public static function verificar(array $datos, ?string $firmaBase64): bool
    {
        if (empty($firmaBase64)) {
            return false;
        }
        self::asegurarLlaves();
        $publica = openssl_pkey_get_public(file_get_contents(self::$pub));
        $ok = openssl_verify(
            self::cadenaCanonica($datos),
            base64_decode($firmaBase64),
            $publica,
            OPENSSL_ALGO_SHA256
        );
        return $ok === 1;
    }
}
