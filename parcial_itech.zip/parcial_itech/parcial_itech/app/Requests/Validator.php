<?php
class Validator
{
    public static function validarInscriptor(array $d): array
    {
        $errores = [];

        if (!self::requerido($d['identidad'] ?? '')) {
            $errores['identidad'] = 'La identidad es obligatoria.';
        } elseif (!preg_match('/^[0-9A-Za-z\-]{5,30}$/', $d['identidad'])) {
            $errores['identidad'] = 'Formato de identidad no válido.';
        }

        if (!self::soloLetras($d['nombre'] ?? '')) {
            $errores['nombre'] = 'El nombre solo debe contener letras.';
        }
        if (!self::soloLetras($d['apellido'] ?? '')) {
            $errores['apellido'] = 'El apellido solo debe contener letras.';
        }

        $edad = filter_var($d['edad'] ?? '', FILTER_VALIDATE_INT);
        if ($edad === false || $edad < 15 || $edad > 100) {
            $errores['edad'] = 'La edad debe ser un número entre 15 y 100.';
        }

        if (!in_array($d['sexo'] ?? '', ['Masculino', 'Femenino', 'Otro'], true)) {
            $errores['sexo'] = 'Seleccione un sexo válido.';
        }

        if (!ctype_digit((string)($d['pais_residencia_id'] ?? ''))) {
            $errores['pais_residencia_id'] = 'Seleccione el país de residencia.';
        }
        if (!ctype_digit((string)($d['nacionalidad_id'] ?? ''))) {
            $errores['nacionalidad_id'] = 'Seleccione la nacionalidad.';
        }

        if (!self::correo($d['correo'] ?? '')) {
            $errores['correo'] = 'Correo electrónico no válido.';
        }

        if (!self::celular($d['celular'] ?? '')) {
            $errores['celular'] = 'Celular no válido (7 a 15 dígitos).';
        }

        if (empty($d['temas']) || !is_array($d['temas'])) {
            $errores['temas'] = 'Seleccione al menos un tema tecnológico.';
        }

        return $errores;
    }

    public static function requerido($v): bool
    {
        return trim((string)$v) !== '';
    }

    public static function soloLetras($v): bool
    {
        return (bool) preg_match('/^[\p{L}\s\'\.\-]{2,100}$/u', trim((string)$v));
    }

    public static function correo($v): bool
    {
        return (bool) filter_var(trim((string)$v), FILTER_VALIDATE_EMAIL);
    }

    public static function celular($v): bool
    {
        $limpio = preg_replace('/[\s\-\+\(\)]/', '', (string)$v);
        return (bool) preg_match('/^[0-9]{7,15}$/', $limpio);
    }
}
