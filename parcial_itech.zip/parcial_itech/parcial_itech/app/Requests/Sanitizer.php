<?php
class Sanitizer
{
    public static function limpiarInscriptor(array $d): array
    {
        return [
            'identidad'          => self::texto($d['identidad'] ?? ''),
            'nombre'             => self::tituloCase($d['nombre'] ?? ''),
            'apellido'           => self::tituloCase($d['apellido'] ?? ''),
            'edad'               => self::entero($d['edad'] ?? 0),
            'sexo'               => self::texto($d['sexo'] ?? ''),
            'pais_residencia_id' => self::entero($d['pais_residencia_id'] ?? 0),
            'nacionalidad_id'    => self::entero($d['nacionalidad_id'] ?? 0),
            'correo'             => self::correo($d['correo'] ?? ''),
            'celular'            => self::soloNumeros($d['celular'] ?? ''),
            'observaciones'      => self::texto($d['observaciones'] ?? ''),
            'temas'              => array_map('intval', (array)($d['temas'] ?? [])),
        ];
    }
    public static function texto($v): string
    {
        $v = strip_tags((string)$v);
        $v = trim($v);
        return preg_replace('/\s+/u', ' ', $v);
    }

    public static function tituloCase($v): string
    {
        $v = self::texto($v);
        if (function_exists('mb_convert_case')) {
            return mb_convert_case(mb_strtolower($v, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
        }
        return ucwords(strtolower($v));
    }

    public static function correo($v): string
    {
        return filter_var(trim(strtolower((string)$v)), FILTER_SANITIZE_EMAIL);
    }

    public static function soloNumeros($v): string
    {
        return preg_replace('/[^0-9]/', '', (string)$v);
    }

    public static function entero($v): int
    {
        return (int) filter_var($v, FILTER_SANITIZE_NUMBER_INT);
    }
}
