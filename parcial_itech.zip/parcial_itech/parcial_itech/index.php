<?php
require_once __DIR__ . '/app/bootstrap.php';

$controller = new InscriptorController();
$accion = $_GET['accion'] ?? 'formulario';

switch ($accion) {
    case 'guardar':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->guardar();
        } else {
            $controller->formulario();
        }
        break;

    case 'reporte':
        $controller->reporte();
        break;

    case 'formulario':
    default:
        $controller->formulario();
        break;
}
