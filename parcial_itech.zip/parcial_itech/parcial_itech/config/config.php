<?php
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'parcial_itech');
define('DB_USER', 'root');    
define('DB_PASS', '');         
define('DB_CHARSET', 'utf8mb4');

define('BASE_PATH', dirname(__DIR__));
define('KEYS_PATH', BASE_PATH . '/keys');

// --- Datos del pie de página ---
define('APP_NOMBRE', 'iTECH');
define('APP_CONTACTO', 'info@itech.edu.pa  |  +507 6000-0000');
date_default_timezone_set('America/Panama');
